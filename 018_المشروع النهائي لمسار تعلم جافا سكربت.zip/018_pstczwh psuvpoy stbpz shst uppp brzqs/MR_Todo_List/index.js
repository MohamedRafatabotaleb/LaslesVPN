import { initEventListeners } from "./Scripts/eventListeners";

// Initialize event listeners
initEventListeners();
